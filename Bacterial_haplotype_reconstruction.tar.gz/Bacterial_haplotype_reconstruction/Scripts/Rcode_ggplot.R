##First read in the arguments listed at the command line
require(ggplot2) 
args=(commandArgs(TRUE))

for(i in 1:length(args)){
         eval(parse(text=args[[i]]))
}

dat<-read.table(file=myFile, header=T)

pdf(file=myTitle, height=8, width=8)
bp <- ggplot(dat, aes(Genome_position, Number_Haplotype_Blocks,group = as.factor(d))) +geom_line() 
#bp
bp + labs(title=myTitleGraph)
colnames(dat)[2:3] <- c("T", "F") 
 
dis <- unique(dat$d) 

dev.off()

