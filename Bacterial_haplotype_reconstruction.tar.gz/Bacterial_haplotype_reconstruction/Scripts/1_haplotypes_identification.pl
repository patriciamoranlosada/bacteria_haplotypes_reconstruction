###############################################################################################
# Identification of bacterial haplotypes blocks based on pairwise comparisons.                #
# The script will take all SNPs present for each strain and will create a matrix to           #
# identify all different haplotypes and their lengths.                                        #
# INPUT: The script will merge all .txt files present in the forder, which contains           #
# the SNPs information.           							      #
# INPUT FORMAT : NAME_STRAIN\tSNP_POSITION\tNT_REF\tNT_STRAIN(last two columns are optional)  #
# Example of a row of the INPUT_format: NF33	32	A	T		              #
# USAGE : perl haplotypes_identification.pl						      #		
# The script will ask the name of the reference genome which will be added into the analysis  #
# OUTPUT :  The file Haplotype_distances_hp.txt will report all different haplotype blocks    #
# for all comparisons. It will contain the number of haplotypes, the length of                #
# them based on the number of syntenic SNPs and physical length.          		      #
# 											      #
# More information in Readme.txt file							      #	
#											      #
# Patricia Morán Losada -> MoranLosada.Patricia@mh-hannover.de		 		      #				
###############################################################################################

#!/usr/bin/perl

use Cwd;
use strict;
use warnings;
my $dir = cwd;

print "Enter the reference strain name: ";
my $userword = <STDIN>; 
chomp $userword; 
exit 0 if ($userword eq ""); 

system " cat *.txt > all_files_SNPs.txt";
system "sort -r -n -k2 all_files_SNPs.txt > sorted_down_all_files_SNPs.txt";
system "sort -n -k2 all_files_SNPs.txt > sorted_up_all_files_SNPs.txt";
system "rm all_files_SNPs.txt";

my $file = "sorted_up_all_files_SNPs.txt";
my $counter_str = 0;
my %position_SNP = ();
my %names_strain = &strains_files;

my @total_matrix = &read_files;

my ($rev_matrix,$ref_consecutiveSNPs) = &analysis_matrix(@total_matrix);

my @final_reverse_matrix = @$rev_matrix;
my @Total_matrix_consecutiveSNPs = @$ref_consecutiveSNPs;

&add_ref;
&Summary_haplotype_blocks(@Total_matrix_consecutiveSNPs);
&haplotypes_nucletide_length;

sub strains_files{
	unless(open(INPUT, $file)){
        print "the file \"$file\" can't be opened!\n";
        exit;}
	my $counter_snp = 1;	
	while (my $line = <INPUT>) {
		chomp ($line);
		my @data = split (/\t/,$line);	
		my $strain = $data[0];
		my $SNP = $data[1];
		if (!exists($names_strain{$strain})){
			$names_strain{$strain} = $counter_str;
			$counter_str++;
			open (OUT_strain, ">>$dir/strains.txt");
			print OUT_strain "$strain\n";
			close OUT_strain;

		}
		open (OUTFILE, ">>$dir/SNPs.$strain.txt");
		print OUTFILE "$line\n";
		close OUTFILE;

		if (!exists($position_SNP{$SNP})){
			$position_SNP{$SNP} = $counter_snp;
			open (OUT, ">>$dir/uniqueSNPs_sorted.txt");
			print OUT "$SNP\t$counter_snp\n";
			close OUT;
			$counter_snp++;

			open (OUT_MAT, ">>$dir/TOTAL_MATRIX.txt");
               		print OUT_MAT "$SNP\t";
                	close OUT_MAT;
		}
	}
	open (OUT_MAT, ">>$dir/TOTAL_MATRIX.txt");
	print OUT_MAT "\n";
	close OUT_MAT;
	open (OUT_strain, ">>$dir/strains.txt");
	print OUT_strain "$userword\n";
	close OUT_strain;
	return %names_strain;
}


sub read_files{
	opendir(DIR, $dir) or die "can't open dir $dir: $! \n";
	my @files=readdir(DIR);
	closedir DIR;
	my $counter = 0;
	my @AoA;	       

	foreach my $file (@files) {
		if($file =~ m/^SNPs./) {
			
			my @data_files = split(/\./, $file);
			my $strain = $data_files[1];
			
			unless(open(INPUT, $file)){
			print "the file \"$file\" can't be opened!\n";
			exit;}
			
			my %position_SNPs = ();
 			
			while (my $line = <INPUT>) {
				chomp ($line);			
				my @data = split (/\t/,$line);
				my $position_SNP = $data[1];
			
				if (!exists($position_SNPs{$position_SNP})){
					$position_SNPs{$position_SNP} = 0;
				}
				else{
					warn "The strain $strain has more than one time the position $position_SNP\n"		
				}					
			}
			my @matrix = &create_matrix(\%position_SNPs, $strain, $counter);
			push(@AoA, [@matrix]);
			
			$counter++;
		}
	}


	return @AoA;
}

sub create_matrix{
	my %position_SNPs = %{$_[0]};
	my $strain = $_[1];	
	my $counter = $_[2];

	open (OUTPUT, ">>$dir/order_strains.txt");
	print OUTPUT "$counter\t$strain\n";
	close OUTPUT;

	my $file = "uniqueSNPs_sorted.txt";
	unless(open(INPUT, $file)){
	print "the file \"$file\" can't be opened!\n";
	exit;}
	
	my @matrix = ();	
	while (my $line = <INPUT>){
		chomp ($line);
		my @data = split (/\t/, $line);
		my $all_SNP_position = $data[0];
		my $all_counter_SNP = $data [1];
		
		if (!exists($position_SNPs{$all_SNP_position})){
			push (@matrix,0);	
		}
		else {
			push (@matrix,1);	
		}
	}
	  
	return @matrix;
}		

sub analysis_matrix{
	my @Final_matrix = @_;
	my @matrix_reverse;

	foreach my $i (@Final_matrix) {
		my @reverse = reverse@$i;
		push(@matrix_reverse,[@reverse]);
	}
   
	my $a = 0;
	my $equal = 1;
	my $not_equal = 0;
	my $counter_elements = -1;
	my $match = 0;
	my $counter_match = 0;
	my $scalar_mat = scalar(@matrix_reverse);
	my $ref1 = $scalar_mat +1;
	my @ref1;
	
	for (my $b = 0; $b <= $#{$matrix_reverse[$a]}; $b++) {
		$counter_elements++;
		push (@ref1,0);
		open (OUT_MAT, ">>$dir/TOTAL_MATRIX.txt");
		print OUT_MAT "$counter_elements\t";
		close OUT_MAT;

	}
	open (OUT_MAT, ">>$dir/TOTAL_MATRIX.txt");
	print OUT_MAT "\n";
	close OUT_MAT;
	
	push(@matrix_reverse,[@ref1]);
	my $scalar_matrix = scalar(@matrix_reverse);
	my $final_point = $scalar_matrix -1;
	my @final_reverse_matrix ;
	my $b = 1;

	for ( my $a= 0 ; $a < $final_point ; $a++){
		for ( $b ; $b < $scalar_matrix ; $b++){
			my @new_matrix;
			for (my $c = 0; $c <= $counter_elements ; $c++){   
				if (($matrix_reverse[$a][$c] == $matrix_reverse[$b][$c]) && ($match == 0)){
					push (@new_matrix,$equal);
					$match = 1;
					$counter_match++;
				}
				elsif (($matrix_reverse[$a][$c] == $matrix_reverse[$b][$c]) && ($match == 1)){
					push (@new_matrix,$counter_match+1);
					$counter_match++;
				}
				else {
					push (@new_matrix,$not_equal);
					$counter_match = 0;
					$match = 0;
				}
			}
			push(@final_reverse_matrix, [@new_matrix]);
			$match = 0;
			$counter_match = 0;
		}
		$b = $a+2;
	}

	my @Total_matrix;
	foreach my $i (@final_reverse_matrix) {
		my @reverse_final = reverse@$i;
		push(@Total_matrix,[@reverse_final]);
        }
	
	my %summary = ();
	my @data_graph;
	my %pair_summary = ();
	my $sum_values = 0;

	for (my $x = 0; $x <= $#Total_matrix; $x++) {
		for (my $y = 0; $y <= $#{$Total_matrix[$x]}; $y++) {
			open (OUT_MAT, ">>$dir/TOTAL_MATRIX.txt");
                	print OUT_MAT "$Total_matrix[$x][$y]\t";
	        	close OUT_MAT;

			$sum_values = $sum_values + $Total_matrix[$x][$y];

						
			push(@data_graph,$Total_matrix[$x][$y]);
			if ($y == $counter_str ){
				&sum_array(@data_graph);
			}
			elsif ($y > $counter_str){
				shift(@data_graph);
				&sum_array(@data_graph);
			}

			
              		
			$summary{"$Total_matrix[$x][$y]"}++;

			if ($Total_matrix[$x][$y] > 1){ # haplotype block min 2 SNPs
				$pair_summary{"$Total_matrix[$x][$y]"}++;
			}
		}	
		
		%pair_summary = ();
		
		open (OUT_MAT, ">>$dir/TOTAL_MATRIX.txt");
		print OUT_MAT "\n";
		close OUT_MAT;

		@data_graph = ();
        }


	return (\@final_reverse_matrix,\@Total_matrix);	
}

sub sum_array{
	my @a = @_;
	my $acc = 0;
	foreach (@a){
  		$acc += $_;
	}

	open (OUT_GRAPH, ">>$dir/Second_graph.txt");
	print OUT_GRAPH "$acc\n";
	close OUT_GRAPH; 
}

sub add_ref {
	my $file = "order_strains.txt";
        unless(open(INPUT, $file)){
        print "the file \"$file\" can't be opened!\n";
        exit;}
	
	my @strain_total;
	my $number;
	my $strain;
	while (my $line = <INPUT>){
		chomp ($line);
		my @data = split (/\t/, $line);
		$number = $data[0];
		$strain = $data[1];
		push (@strain_total,$strain);
	}
	close INPUT;
	my $last_strain_number = $number +1;
	my $last_strain = $userword;
	push (@strain_total,$last_strain);

	my $y = 1;
	my $x;
	my $counter_comb = 0;

	for ( $x = 0; $x <= $#strain_total; $x++) {
                for ( $y; $y <= $#strain_total; $y++) {
                        $counter_comb++;
			open (OUT_COMB, ">>$dir/combinations.txt");
			print OUT_COMB "$strain_total[$x]_$strain_total[$y]\t$counter_comb\n";
			close OUT_COMB; 
                }	
		$y = $x +2;
	}
	
	open (OUT_ORDER, ">>$dir/order_strains.txt");
	print OUT_ORDER  "$last_strain_number\t$last_strain";
	close OUT_ORDER;
}

sub search_combination {
	my $x = $_[0];
	my $file_combinations = "combinations.txt";
	unless(open(INPUT_combinations, $file_combinations)){
	print "the file \"$file_combinations\" can't be opened!\n";
	exit;}
	my $count_line_combinations = -1;
	while (my $line = <INPUT_combinations>){
		chomp ($line);
		$count_line_combinations++;
		my @data = split (/\t/,$line);
		my $pair_combination = $data[0];
		if ($x == $count_line_combinations){
			return $pair_combination;
		}
	}
	close INPUT_combinations;
}


sub Summary_haplotype_blocks{
        my @matrix = @_;
        my $old_value = 0;
        my $haplotype_counter = 0;
        my %length_haplotype = ();
	my %length_combination = ();

	open (OUT_HAPLOTYPE,">>$dir/Summary_real_length.txt");
	print OUT_HAPLOTYPE "Number_haplotype\tLength\tstart\tend\tcomparison\n";
	close OUT_HAPLOTYPE;
        for (my $x = 0; $x <= $#matrix; $x++) {
                for (my $y = 0; $y <= $#{$matrix[$x]}; $y++) {
			
                        if (($y == 0) && ($matrix[$x][$y] > 1)) {
                                $haplotype_counter++;
                                $length_haplotype{$matrix[$x][$y]}++;
				$length_combination{$matrix[$x][$y]}++;
				
				
				my $value_st= $matrix[$x][$y];
				my $point_end = $y + $value_st -1;
                                open(OUT_HAPLOTYPE, ">>$dir/Summary_real_length.txt");
                                print OUT_HAPLOTYPE "$haplotype_counter\t$matrix[$x][$y]\t$y\t$point_end\t$x\n";
                                close OUT_HAPLOTYPE;

				

                        }
                        elsif (($matrix[$x][$y] > 1) && ($old_value == 0) && ($y > 0)){
                                $haplotype_counter++;
                                $length_haplotype{$matrix[$x][$y]}++;
				$length_combination{$matrix[$x][$y]}++;				
				
				my $value_st= $matrix[$x][$y];
				my $point_end = $y + $value_st -1;
			
                                open (OUT_HAPLOTYPE,">>$dir/Summary_real_length.txt");
                                print OUT_HAPLOTYPE "$haplotype_counter\t$matrix[$x][$y]\t$y\t$point_end\t$x\n";
                                close OUT_HAPLOTYPE;

				
                        }

                        $old_value = $matrix[$x][$y];
		}
			my $pair_combination = &search_combination($x);


			%length_combination =();			
		
        }

}
	
sub haplotypes_nucletide_length {
	my $in = "$dir/TOTAL_MATRIX.txt"; # TOTAL_MATRIX.txt file
	chomp $in;
	
	unless(open(IN, $in)){
	print "the file \"$in\" can't be opened!\n";
	exit;}
	my $infile = "$dir/combinations.txt"; # combinations.txt file
	chomp $infile;
	
	unless(open(INPUT, $infile)){
	print "the file \"$infile\" can't be opened!\n";
	exit;}
	my $infile3 = "$dir/Summary_real_length.txt"; # Summary_real_length.txt - file with all the haplotype blocks 
	chomp $infile3;
	
	unless(open(INPUT3, $infile3)){
	print "the file \"$infile3\" can't be opened!\n";
	exit;}

	my $line_counter = 0;

	while (my $line = <IN>){
	chomp ($line);
	$line_counter++;
		if ($line_counter== 1){
			open (OUT_first, ">>$dir/first_line_matrix.txt");
	      	 	print OUT_first "$line\n";
	       		close OUT_first;
		}
		elsif ($line_counter == 2) {
			open (OUT_second, ">>$dir/second_line_matrix.txt");
		        print OUT_second "$line\n";
		        close OUT_second;
			
		}
	}

	my $infile2 = "$dir/first_line_matrix.txt";
	chomp $infile2;
	
	unless(open(INPUT2, $infile2)){
	print "the file \"$infile2\" can't be opened!\n";
	exit;}


	my %pair =();

	while (my $line = <INPUT>){
	chomp ($line);
		my @data = split (/\t/,$line);
		my $combination = $data[0];
		my $comb_number = $data[1];
		$pair{$comb_number}=$combination;
	}

	my %genome_position =();
	my $x;
	while (my $line = <INPUT2>){
	chomp ($line);
		my @genome_pst = split(/\t/,$line);
		for ($x = 0; $x <= $#genome_pst; $x++) {
			$genome_position{$x} = $genome_pst[$x];
		}
	}

	my $count=0;
	my %lengths =();
	while (my $line = <INPUT3>){
		chomp ($line);
		$count++;
			if ($count == 1){
				open (OUT, ">>$dir/Haplotype_distances_hp.txt");
		      		print OUT "Number_haplotype\tConsecutive_SNPs\tSNP_start\tSNP_end\tcomparison\tHb_genome_st\tHb_genome_end\tGenome_length\tcomparison\n";
		      	 	close OUT;
			}
			else{
				my @data = split (/\t/,$line);
				my $hb = $data[0];
				my $SNPs = $data[1];
				my $SNP_st = $data[2];
				my $SNP_end = $data[3];
				my $comparison = $data[4];
				my $real_pair = $comparison+1;
				my $genome_length = $genome_position{$SNP_end} - $genome_position{$SNP_st} +1;
		
				$lengths{$genome_length}++;

				open (OUT, ">>$dir/Haplotype_distances_hp.txt");
				print OUT "$hb\t$SNPs\t$SNP_st\t$SNP_end\t$pair{$real_pair}\t$genome_position{$SNP_st}\t$genome_position{$SNP_end}\t$genome_length\t$pair{$real_pair}\n";
				close OUT;
			}
	}

	foreach my $key (keys %lengths){
		open (OUT_lengths, ">>$dir/Haplotype_genome_lengths.txt");	
		print OUT_lengths "$key\t $lengths{$key}\n";
		close OUT_lengths;
	}	
	system "sort -n -k1 Haplotype_genome_lengths.txt > Haplotype_nucleotide_lengths_sorted.txt";
	system "rm Haplotype_genome_lengths.txt ";
	
	close INPUT;
	close INPUT2;
	close INPUT3;	
}	

system "rm order_strains.txt";
system "rm combinations.txt";
system "rm SNPs.*.txt";
system "rm first_line_matrix.txt";
system "rm Haplotype_nucleotide_lengths_sorted.txt";
system "rm Second_graph.txt";
system "rm second_line_matrix.txt";
system "rm sorted_down_all_files_SNPs.txt";
system "rm sorted_up_all_files_SNPs.txt";
system "rm Summary_real_length.txt";

close INPUT;
exit;	
