#!/usr/bin/perl
use Cwd;
use strict;
use warnings;
use Statistics::Lite qw(:all);
my $dir = cwd;

my $infile = "Haplotype_distances_hp.txt"; 
chomp $infile;
#open the file if doesn't exist give an error
unless(open(INPUT, $infile)){
print "the file \"$infile\" can't be opened!\n";
exit;}

my $count =0;
#my $old_pair;

my %hash_snps=();

open (OUT, ">>$dir/unique_consecutive_snps.txt");

while (my $line = <INPUT>){
chomp ($line);
$count++;
	if ($count > 1){
		my @data = split (/\t/,$line);
		my $snps = $data[1];
		if(!exists($hash_snps{$snps})){
			$hash_snps{$snps}=0;
		}
	}
	
}

foreach my $key (keys %hash_snps){
	print OUT "$key\n";
}

close OUT;
close INPUT;

my $counter=0;
system "sort -r -n -k1 unique_consecutive_snps.txt > unique_consecutive_snps_sorted.txt";
system "rm unique_consecutive_snps.txt";

my %rank_numbers=();
my $infile2 = "unique_consecutive_snps_sorted.txt";
chomp $infile2;
#open the file if doesn't exist give an error
unless(open(INPUT2, $infile2)){
print "the file \"$infile2\" can't be opened!\n";
exit;}

while (my $line = <INPUT2>){
chomp ($line);
$counter++;
	$rank_numbers{$line}=$counter;
	open (OUT2, ">>$dir/rank_numbers.txt");
	print OUT2 "$line\t$counter\n";
	close OUT2;
}

my $flag=0;
my %hash_ranks_pair=();
my %hash_median;


my $infile3 = "Haplotype_distances_hp.txt";
chomp $infile3;
#open the file if doesn't exist give an error
unless(open(INPUT3, $infile3)){
print "the file \"$infile3\" can't be opened!\n";
exit;}

open (OUT3, ">>$dir/Genome_distances_hp_rank_numbers.txt");
while (my $line = <INPUT3>){
chomp ($line);
$flag++;
	if ($flag == 1){
		print OUT3 "$line\trank_number\n";
	}
	else{
		my @data = split (/\t/,$line);
		my $consecutive_snps = $data[1];
		my $pair = $data[8];
		if (!exists ($hash_ranks_pair{$pair})){
			$hash_ranks_pair{$pair}=$rank_numbers{$consecutive_snps};
			push (@{$hash_median{$pair}},$rank_numbers{$consecutive_snps});
		
		}
		else{
			$hash_ranks_pair{$pair}=$hash_ranks_pair{$pair}+$rank_numbers{$consecutive_snps};
			push (@{$hash_median{$pair}},$rank_numbers{$consecutive_snps});
		}
	
		print OUT3 "$line\t$rank_numbers{$consecutive_snps}\n";
	}
}
close OUT3;

my %hash_m_matrix=();

foreach my $key (keys %hash_ranks_pair){
	open (OUT4, ">>$dir/sum_rank_number_pairs.txt");
        print OUT4 "$key\t$hash_ranks_pair{$key}\n";
	close OUT4;
	
	my @r = @{$hash_median{$key}};
	my $median  = median(@r);
	
	$hash_m_matrix{$key}=$median;
}

system "sort -r -n -k1 sum_rank_number_pairs.txt > sum_rank_number_pairs_sorted.txt";
system "rm sum_rank_number_pairs.txt";

my %pairs =();
my $c = 0;
my $y =1;
my $infile4 = "strains.txt";
chomp $infile4;
#open the file if doesn't exist give an error
unless(open(INPUT4, $infile4)){
print "the file \"$infile4\" can't be opened!\n";
exit;}

open (OUT5, ">>$dir/matrix_sum_ranks.txt");
open (OUT6, ">>$dir/matrix_median_ranks.txt");
while (my $line = <INPUT4>){
chomp ($line);
$c++;
	$pairs{$c}=$line;
	
}
print OUT5 "$c\n";
print OUT6 "$c\n";

for (my $x = 1; $x <= $c; $x++) {
	

	print OUT5 "$pairs{$x}\t";
	print OUT6 "$pairs{$x}\t";	

	for ($y; $y <=$c; $y++){
		my $strainA = $pairs{$x};
		my $strainB = $pairs{$y};
		my $pair = "$strainA"."_"."$strainB";
		my $pair2 = "$strainB"."_"."$strainA";
		
		if (exists ($hash_ranks_pair{$pair})){
			my $value = $hash_ranks_pair{$pair};
			my $value_median = $hash_m_matrix{$pair};
			print OUT5 "$value\t";
			print OUT6 "$value_median\t";
		}
		elsif (exists ($hash_ranks_pair{$pair2})){
			my $value = $hash_ranks_pair{$pair2};
			my $value_median = $hash_m_matrix{$pair2};
			print OUT5 "$value\t";
			print OUT6 "$value_median\t";
		}
		else {
			my $value = 0;
			print OUT5 "$value\t";
			print OUT6 "$value\t";
		}
	}
	
	print OUT5 "\n";
	print OUT6"\n";
	$y =1;
	#$y=$x+2;;
}
system "rm sum_rank_number_pairs_sorted.txt";
system "rm rank_numbers.txt";
system `mkdir 2_output_files`;
system ` mv Genome_distances_hp_rank_numbers.txt $dir/2_output_files`;
system ` mv matrix_sum_ranks.txt $dir/2_output_files`;
system ` mv matrix_median_ranks.txt $dir/2_output_files`;

exit;
