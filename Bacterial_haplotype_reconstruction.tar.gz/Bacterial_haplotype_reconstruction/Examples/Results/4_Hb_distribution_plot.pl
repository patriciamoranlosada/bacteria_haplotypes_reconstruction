#!/usr/bin/perl
use Cwd;
use Switch;
use strict;
use warnings;
my $dir = cwd;
my $count = 0;
my $h_count=0;

my $file = "Haplotype_distances_hp.txt";		
unless(open(INPUT, $file)){
print "the file \"$file\" can't be opened!\n";
exit;}

	
open(OUTPUT, ">>$dir/Distribution_blocks_total.txt");
print OUTPUT "d\tNumber_Haplotype_Blocks\tGenome_position\n";
close OUTPUT;

open (OUT1, ">>$dir/hb.txt");

while (my $line = <INPUT>){
chomp ($line);
$count++;
	if ($count >1){
		
		my @data = split (/\t/,$line);
		my $haplotype_number = $data[0];
		my $haplotype_st = $data[5];
		my $haplotype_end = $data[6];	
		
		open (OUT1, ">>$dir/hb.txt");
		print OUT1 "$haplotype_st\t$haplotype_end\n";
	}
close OUT1;
}
system "sort -n -k1 -k2 hb.txt > hb_sorted.txt";
system "rm hb.txt";

my $file2 = "hb_sorted.txt";
unless(open(INPUT2, $file2)){
print "the file \"$file2\" can't be opened!\n";
exit;}

while (my $line2 = <INPUT2>){
chomp ($line2);
$h_count++;
	my @hb= split (/\t/,$line2);
	my $st = $hb[0];
	my $end = $hb[1];	
	
	open(OUTPUT, ">>$dir/Distribution_blocks_total.txt");
	print OUTPUT "$h_count\t$h_count\t$st\n$h_count\t$h_count\t$end\n";
	close OUTPUT;
}

	
	my $rfile = "$dir/Rcode_ggplot.R";
	my $file_R = "'Distribution_blocks_total.txt'";
	my $title = "'Distribution_blocks_total.pdf'";
	my $graph_title ="'Distribution haplotype blocks'";
	my $directory = "'$dir'";
	system ("Rscript $rfile \"myFile=$file_R\" \"myTitle=$title\" \"myDir=$directory\" \"myTitleGraph=$graph_title\"");

	
close INPUT;
close INPUT2;
system "rm hb_sorted.txt";
system "mkdir 4_output_files";
system "mv Distribution_blocks_total.txt $dir/4_output_files/";
system "mv Distribution_blocks_total.pdf $dir/4_output_files/";


exit;
