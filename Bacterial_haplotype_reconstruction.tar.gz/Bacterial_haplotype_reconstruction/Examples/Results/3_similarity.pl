#!/usr/bin/perl
use Cwd;
use strict;
use warnings;
use Statistics::Lite qw(:all);
my $dir = cwd;


my $infile = "Haplotype_distances_hp.txt"; 
chomp $infile;
#open the file if doesn't exist give an error
unless(open(INPUT, $infile)){
print "the file \"$infile\" can't be opened!\n";
exit;}
my $infile2 = "TOTAL_MATRIX.txt"; 
chomp $infile2;
#open the file if doesn't exist give an error
unless(open(INPUT2, $infile2)){
print "the file \"$infile2\" can't be opened!\n";
exit;}

my $line_c=0;
my $max;

while (my $line = <INPUT2>){
chomp ($line);
$line_c++;
	
	if ($line_c ==2){
		my @data = split(/\t/,$line);
		my $max_matrix = scalar(@data);
		$max = $max_matrix;
	}
}

my $count =0;
my $count_line=0;
my %hash_snps=();
my %hash_similarity=();
my %hash_length_similarity=();
my %hash_comp =();


while (my $line = <INPUT>){
chomp ($line);
$count_line++;
	if ($count_line>1){
		my @data = split (/\t/,$line);
		my $snps = $data[1];
		my $comparison = $data[4];
		my $k = "$comparison.$snps";
		
		$hash_snps{$k}++;
		if(!exists($hash_comp{$snps})){
			$hash_comp{$snps}++;
			$count++;
		}
		if (!exists($hash_similarity{$comparison})){
			$hash_similarity{$comparison} = $snps;
		}
		else {
			$hash_similarity{$comparison} =$hash_similarity{$comparison}+ $snps;
		}
	}
}

foreach my $key (sort(keys %hash_snps)){
	#open (OUT, ">>$dir/strain_similarities.txt");
	#print OUT "$key\n";
	#close OUT;
	my @pair = split (/\./,$key);
	my $p = $pair[0]; 
	$hash_length_similarity{$p}++;
}
open (OUT2, ">>$dir/hb_unique_length_similarity.txt");
print OUT2 "Comparison\tSimilarity_unique_length_haplotypes(%)\n";
foreach my $key_sim (keys %hash_length_similarity){

	my $simil = ($hash_length_similarity{$key_sim}/$count)*100;	
	print OUT2 "$key_sim\t$simil\n";	
}
close OUT2;


my %percent=();
open (OUT3, ">>$dir/sum_snps_shared.txt");
print OUT3 "Comparison\tSNP_length_shared(%)\n";
foreach my $key_s (keys %hash_similarity){

	my $snp_simil = ($hash_similarity{$key_s}/$max)*100;	
	$percent{$key_s}=$snp_simil;
	print OUT3 "$key_s\t$snp_simil\n";	
}
close OUT3;


my %pairs =();
my $c = 0;
my $y =1;
my $infile4 = "strains.txt";
chomp $infile4;
#open the file if doesn't exist give an error
unless(open(INPUT4, $infile4)){
print "the file \"$infile4\" can't be opened!\n";
exit;}

open (OUT4, ">>$dir/matrix_similarities.txt");
#open (OUT5, ">>$dir/heatmap.txt");
#print OUT5 "Name";
open (OUT5, ">>$dir/heatmap.txt");
print OUT5 "Y,X,Value\n";

while (my $line = <INPUT4>){
chomp ($line);
$c++;
	$pairs{$c}=$line;
	#print OUT5 ",$line";
	
	
}
#print OUT5 "\n";
print OUT4 "$c\n";


for (my $x = 1; $x <= $c; $x++) {
	

	print OUT4 "$pairs{$x}\t";
	#print OUT5 "$pairs{$x}";

	for ($y; $y <=$c; $y++){
		my $strainA = $pairs{$x};
		my $strainB = $pairs{$y};
		my $pair = "$strainA"."_"."$strainB";
		my $pair2 = "$strainB"."_"."$strainA";
		
		print OUT5 "$strainA,$strainB,";
		if (exists ($percent{$pair})){
			my $value = sprintf '%.2f',$percent{$pair};
			
			print OUT4 "$value\t";
			print OUT5 "$value\n";
			
		}
		elsif (exists ($percent{$pair2})){
			my $value = sprintf '%.2f',$percent{$pair2};
			print OUT4 "$value\t";
			print OUT5 "$value\n";
		}
		else {
			my $value = 100;
			print OUT4 "$value\t";
			print OUT5 "$value\n";
			
		}
	}
	
	print OUT4 "\n";
	#print OUT5 "\n";
	$y =1;
	
}

close OUT5;
close OUT4;	

my $rfile = "$dir/Rplot_heatmap_table.R";
my $file_R = "'heatmap.txt'";
my $title = "'Similarity_strains.pdf'";
my $graph_title ="'Similarity between Strains'";
my $directory = "'$dir'";
system ("Rscript $rfile \"myFile=$file_R\" \"myTitle=$title\" \"myDir=$directory\" \"myTitleGraph=$graph_title\"");

system `mkdir 3_output_files`;
system ` mv sum_snps_shared.txt $dir/3_output_files`;
system `mv matrix_similarities.txt $dir/3_output_files`;
system `mv Similarity_strains.pdf $dir/3_output_files`;
system `mv heatmap.txt $dir/3_output_files`;
system `mv hb_unique_length_similarity.txt $dir/3_output_files`;
close INPUT;
exit;
