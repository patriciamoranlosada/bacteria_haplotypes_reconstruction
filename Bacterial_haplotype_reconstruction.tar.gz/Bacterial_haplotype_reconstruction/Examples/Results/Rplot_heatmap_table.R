##First read in the arguments listed at the command line
require(lattice)
library(lattice)
args=(commandArgs(TRUE))

for(i in 1:length(args)){
         eval(parse(text=args[[i]]))
}

m  <- read.table(file=myFile, sep = ",", header=TRUE,  check.names=FALSE, stringsAsFactors=TRUE)
pdf(file=myTitle, height=8, width=8)


col.l <- colorRampPalette(c("grey","pink","deeppink","yellow","orange","red","forestgreen","cyan","blue","black"))


#levelplot(Value ~ X + Y, data = m,col.regions=colorRampPalette(c("black","yellow","orange","red","darkgreen","blue")), scales=list(x=list(rot=90)), xlab="",ylab="")
levelplot(Value ~ X + Y, data = m,xlab="",ylab="",scales=list(x=list(rot=90)),
   at=seq(0,105,10),  col.regions=col.l,

colorkey=list(at=as.numeric(factor(c(seq(0,105,10)))),
               labels=as.character(c( "0%", "10%","20%","30%", "40%","50%", "60%","70%", "80%","90%", "100%")),
               col=(col.l)))
dev.off()


